export default {
  cake: {
    56: '0x8C9dDbc86a5cA4D3065010aB0c2CbAecaa70C6aB',
    97: '0x8C9dDbc86a5cA4D3065010aB0c2CbAecaa70C6aB',
  },
  masterChef: {
    56: '0x63B63e6BB30C64e1b09d86A6Fb7230235Bb09B39',
    97: '0x63B63e6BB30C64e1b09d86A6Fb7230235Bb09B39',
  },
  masterChefCompound: {
    56: '0xEc4A9356AFf0bb78Fa6d936942FC30f444e9ffc7',
    97: '0xEc4A9356AFf0bb78Fa6d936942FC30f444e9ffc7',
  },
  wbnb: {
    56: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    97: '0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd',
  },
  lottery: {
    56: '',
    97: '',
  },
  lotteryNFT: {
    56: '',
    97: '',
  },
  mulltiCall: {
    56: '0x1ee38d535d541c55c9dae27b12edf090c608e6fb',
    97: '0x67ADCB4dF3931b0C5Da724058ADC2174a9844412',
  },
  busd: {
    56: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
    97: '0x78867bbeef44f2326bf8ddd1941a4439382ef2a7',
  },
}